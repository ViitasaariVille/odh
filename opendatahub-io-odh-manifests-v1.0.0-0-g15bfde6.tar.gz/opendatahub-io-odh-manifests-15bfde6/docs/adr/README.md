## Architectural Decisions

We keep track of architectural decisions using a lightweigh architectural decision records. More information on the
used format is available at https://adr.github.io/madr/. General information about architectural decision records
is available at https://adr.github.io/ .

### Architectural Decisions

* [ADR-0000](0000-odh-release-policy.md) - The Open Data Hub Release Policy